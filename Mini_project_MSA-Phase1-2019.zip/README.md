The original data contains information for every player registered in the latest
edition of FIFA19 database. The source of data is https://sofifa.com/.

Our data contain 36 variables: Overall - overall rate (scale of 100), Position - Position on the pitch(0 and 1) and 34 performance scores (scale of 100) follow:Crossing,Finishing, HeadingAccuracy, ShortPassing, Volleys, Dribbling,Curve, FKAccuracy, LongPassing, BallControl, Acceleration, SprintSpeed,Agility, Reactions, Balance, ShotPower, Jumping, Stamina,Strength, LongShots, Aggression, Interceptions, Positioning,Vision, Penalties, Composure, Marking, StandingTackle, SlidingTackle,GKDiving, GKHandling, GKKicking, GKPositioning, GKReflexes

Our interest is to choose the useful variables from 34 performance scores to fit a linear regression model to predict Overall scores. Moreover, use the 34 performance scores to fit a random forest model to predict the Position.
